import { NgModule } from '@angular/core';
import { AccordionComponent } from './accordion/accordion';
@NgModule({
	declarations: [AccordionComponent],
	imports: [],
	exports: [AccordionComponent]
})
export class ComponentsModule {}
